
#ifndef _AnyMSG_COMMON_H_
#define _AnyMSG_COMMON_H_

#include <stdio.h>   
#include <stdlib.h>  
#include <string.h>     // 使用 malloc, calloc等动态分配内存方法
#include <stdbool.h>
#include "sys.h"

typedef struct login_node
{
	char *alias;
	char *appKey;
	char *uuid;
	char *code;
}login_node;
//#include <time.h>
//#include "tcp_client_demo.h" 
typedef struct msgs
{
	u16 		        msg_length;//
	s8              retries;
	u8              _reserved_;
	u32 				    _src_handler_;
	u32 				    destination_cid;
	u32 				    source_cid;
	u32             local_time;
	u8              verify_string[16];
	u16 		        content_length;
	u8              type;
	u8					    __PADDING__;
}msg_t ;

// AnyMSG根据data[0]判别数据包类型    比如0x81 = 0x80 | 0x1 为一个txt类型数据包
typedef enum{
    WCT_MINDATA = -20,      // 0x0：标识一个中间数据包
    WCT_TXTDATA = -19,      // 0x1：标识一个txt类型数据包
    WCT_BINDATA = -18,      // 0x2：标识一个bin类型数据包
    WCT_DISCONN = -17,      // 0x8：标识一个断开连接类型数据包
    WCT_PING = -16,     // 0x8：标识一个断开连接类型数据包
    WCT_PONG = -15,     // 0xA：表示一个pong类型数据包
    WCT_ERR = -1,
    WCT_NULL = 0
}AnyMSG_CommunicationType;
typedef enum
{
	MSG_TYPE_HEAR76T_PKG = 0,
	MSG_TYPE_HEART_PKG_REP,
	MSG_TYPE_RTT,
	MSG_TYPE_RTT_REP,
	MSG_TYPE_SERVER_TO_CLIENT,
	MSG_TYPE_CLIENT_TO_SERVER,
	MSG_TYPE_CLIENT_TO_CLIENT,

	MSG_TYPE_WELCOME,
	MSG_TYPE_LOGIN,
	MSG_TYPE_LOGOUT,

	MSG_TYPE_WARN_ANOTHER,

	MSG_TYPE_USER_MSG,
	MSG_TYPE_USER_MSG_REP,
	MSG_TYPE_USER_UID2CID_QUERY,
	MSG_TYPE_USER_ONLINE_LIST_QUERY,
	MSG_TYPE_USER_SOMEONE_INFO_QUERY,
	MSG_TYPE_USER_P2P_INFO_QUERY,
	MSG_TYPE_USER_UPDATE,
	MSG_TYPE_USER_CUSTOM,
	MSG_TYPE_FILE_MSG,
	MSG_TYPE_FILE_REP,
	MSG_TYPE_RTAP,
	MSG_TYPE_RTAP_REP,

	MSG_TYPE_P2PS0,
	MSG_TYPE_P2PS1,
	MSG_TYPE_P2PS2,
	MSG_TYPE_P2PS3,
	MSG_TYPE_P2PS4,
	MSG_TYPE_P2PS5,//28

	MSG_TYPE_RTDP,
	MSG_TYPE_RTDP_REP,

	MSG_TYPE_MAIN_THREAD_KILL,
	MSG_TYPE_CLIENT_THREAD_KILL,
	MSG_TYPE_PIC_MSG,
	MSG_TYPE_PIC_MSG_REP,
	//_MSG_TYPE_RESTRIC_SIZE_4_ = 0xFFFFFFFFUL
}msg_type_e;

#define	AnyMSG_MSG_TYPE_HEART_PKG					"2000"
#define	AnyMSG_MSG_TYPE_HEART_PKG_REP				"2001"
#define	AnyMSG_MSG_TYPE_RTT							"2002"
#define	AnyMSG_MSG_TYPE_RTT_REP						"2003"
#define	AnyMSG_MSG_TYPE_SERVER_TO_CLIENT			"2004"
#define	AnyMSG_MSG_TYPE_CLIENT_TO_SERVER			"2005"
#define	AnyMSG_MSG_TYPE_CLIENT_TO_CLIENT			"2006"

#define	AnyMSG_MSG_TYPE_WELCOME						"2007"
#define	AnyMSG_MSG_TYPE_LOGIN						"2008"
#define	AnyMSG_MSG_TYPE_LOGOUT						"2009"

#define	AnyMSG_MSG_TYPE_WARN_ANOTHER				"2010"

#define	AnyMSG_MSG_TYPE_USER_MSG					"2011"
#define	AnyMSG_MSG_TYPE_USER_MSG_REP				"2012"
#define	AnyMSG_MSG_TYPE_USER_UID2CID_QUERY			"2013"
#define	AnyMSG_MSG_TYPE_USER_ONLINE_LIST_QUERY		"2014"
#define	AnyMSG_MSG_TYPE_USER_SOMEONE_INFO_QUERY		"2015"
#define	AnyMSG_MSG_TYPE_USER_P2P_INFO_QUERY			"2016"
#define	AnyMSG_MSG_TYPE_USER_UPDATE					"2017"
#define	AnyMSG_MSG_TYPE_USER_CUSTOM					"2018"
#define	AnyMSG_MSG_TYPE_FILE_MSG					"2019"
#define	AnyMSG_MSG_TYPE_FILE_REP					"2020"

#define	AnyMSG_MSG_TYPE_MAIN_THREAD_KILL			"2021"
#define	AnyMSG_MSG_TYPE_CLIENT_THREAD_KILL			"2022"

int AnyMSG_buildShakeKey(unsigned char *key);
int AnyMSG_buildRespondShakeKey(unsigned char *acceptKey, unsigned int acceptKeyLen, unsigned char *respondKey);
int AnyMSG_matchShakeKey(unsigned char *myKey, unsigned int myKeyLen, unsigned char *acceptKey, unsigned int acceptKeyLen);
void AnyMSG_buildHttpHead(char *ip, int port, char *interfacePath, unsigned char *shakeKey, char *package);
int AnyMSG_serverLinkToClient(int fd, char *recvBuf, unsigned int bufLen);
int AnyMSG_enPackage(unsigned char *data, unsigned int dataLen, unsigned char *package, unsigned int packageMaxLen, bool isMask, AnyMSG_CommunicationType type);
void delayms(unsigned int ms);

#endif

