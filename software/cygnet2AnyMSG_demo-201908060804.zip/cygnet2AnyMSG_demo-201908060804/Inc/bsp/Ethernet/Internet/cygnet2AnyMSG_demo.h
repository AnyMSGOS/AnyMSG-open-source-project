#ifndef __CYGNET2AnyMSG_DEMO_H
#define __CYGNET2AnyMSG_DEMO_H
#include "bsp/Ethernet/W5500/types.h"
#include "AnyMSG_common.h"
extern uint16 W5500_tcp_server_port;
void AnyMSG_client(void);//TCP Clinet�ػ���ʾ����
int AnyMSG_send(unsigned char *data, unsigned int dataLen, AnyMSG_CommunicationType type);
int AnyMSG_depackge(char *data);
int AnyMSG_pack_send(unsigned char *type,char *buff, unsigned long int buffsize);
#endif 

