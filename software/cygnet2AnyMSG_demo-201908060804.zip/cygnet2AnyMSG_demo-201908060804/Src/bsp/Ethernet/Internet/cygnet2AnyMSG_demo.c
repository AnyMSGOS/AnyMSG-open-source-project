#include <stdio.h>
#include <string.h>
#include "Ethernet/Internet/cygnet2AnyMSG_demo.h"
#include "Ethernet/W5500/W5500_conf.h"
#include "Ethernet/W5500/w5500.h"
#include "Ethernet/W5500/socket.h"
#include "Ethernet/W5500/utility.h"
#include <ctype.h>
#include "bsp_led.h"
#include "usart/bsp_debug_usart.h"
#include "Ethernet/Internet/dns.h"

uint8 msgheadbuff[2];				                              	         
uint8 msgheadbuff2[2];
u32 scid;
u32 dcid=0;
extern char cpuid[24];
#define init_scid 34819
/*��һֱ���ͣ�����������Ӧ������������*/
u32 hbsendflag=0;
/*��������ʱ������6��û���յ���������Ӧ��������������Ϊ��������Ͽ����ӣ��������֣���¼�����·���cid;*/
u8 hbrecvtimeflag=0;
/*��������������ȷCID������1*/
uint8 c2c_suce_flag=0;
/*���������� Ĭ�Ϲر�*/
extern uint8 hbflag;
/**
*@brief		AnyMSG Client�ػ���ʾ������
*@param		��
*@return	��
*/
int AnyMSG_hs_flag=0;
int loginflag=0;
int AnyMSGdatalen=0;
#define MSG_HEAD_LENGTH 40
u8 mpphead[MSG_HEAD_LENGTH];
extern uint32 hbtime;//��������ʱ
extern uint32  uartsendtime;//���ڻ��������ͼ�ʱ
u16 hslgreflag=0;//����&��¼��ʱ����
void AnyMSG_client(void)
{	
	int i,j;
  uint16 len=0;
	u16 uartlen=0;
	u16 tcp_time_num=0;
	uint8 sn_sr;
	u32 AnyMSGdatalen;
	u8 left,right;
	u8 sysreflag=0;
	char *p;
	char webipaddr[15];
  login_node pack;
  char loginpack[200];
	uint8 buff[4096];
	unsigned char loginBuf[512] = {0}, shakeKey[128] = {0};
  pack.code = "2008";
	pack.appKey = "db8e6b9f07264037b230bd83a7c344071a4c5ecee33d481280201cd55aff4f3a";
	pack.uuid = "122";
	sprintf((char *)loginpack,
	"{\"opr\":{\"code\": \"%s\"},\"msg\":{\"appKey\": \"%s\",\"alias\": \"%s\",\"uuid\": \"%s\"}}", pack.code,
	pack.appKey,cpuid, pack.uuid);
	memset(webipaddr,0,15);
	sprintf(webipaddr,"%d.%d.%d.%d",ConfigMsg.rip[0],ConfigMsg.rip[1],ConfigMsg.rip[2],ConfigMsg.rip[3]);
	while(1)
	{
		cta:
		sn_sr=getSn_SR(SOCK_TCPC);
		if(sn_sr!=SOCK_ESTABLISHED)
		{
			LED3_ON;
			delay_ms(200);
			tcp_time_num++;
			LED3_OFF;
			if(tcp_time_num>=300)
			{
				do_dns();
				tcp_time_num=0;
				if(sysreflag>2)
				{
					sysre:
					reboot();
					sysreflag=0;
				}
					sysreflag++;
			}
		}
		switch(getSn_SR(SOCK_TCPC))								  				         /*��ȡsocket��״̬*/
		{	
			case SOCK_CLOSED:											        		         /*socket���ڹر�״̬*/
				socket(SOCK_TCPC,Sn_MR_TCP,local_port++,Sn_MR_ND);
				break;
			
			case SOCK_INIT:													        	         /*socket���ڳ�ʼ��״̬*/
				connect(SOCK_TCPC,ConfigMsg.rip,remote_port);                /*socket���ӷ�����*/
				break;
			
			case SOCK_ESTABLISHED: 			/*socket�������ӽ���״̬*/
				tcp_time_num=0;
				sysreflag=0;			
			if(getSn_IR(SOCK_TCPC) & Sn_IR_CON)
			{
				setSn_IR(SOCK_TCPC, Sn_IR_CON); 							         /*Sn_IR��CONλ��1��֪ͨW5500�����ѽ���*/
			}
			if((!AnyMSG_hs_flag))
			{
				memset(shakeKey, 0, sizeof(shakeKey));
				AnyMSG_buildShakeKey(shakeKey);
			
				memset(loginBuf, 0, sizeof(loginBuf));  // ����Э���
				AnyMSG_buildHttpHead(webipaddr, remote_port,"/null", shakeKey, (char *)loginBuf);
				send(SOCK_TCPC,loginBuf,strlen((char *)loginBuf));
				delay_ms(50);
				if(hslgreflag>1200)
				{
					goto sysre;
				}
				hslgreflag++;
			}
			wel:
			if((AnyMSG_hs_flag) &&(!loginflag))
			{
				AnyMSG_send((unsigned char *)loginpack,strlen(loginpack),WCT_TXTDATA);
				delay_ms(50);
				if(hslgreflag>1200)
				{
					goto sysre;
				}
				hslgreflag++;
			}
			if(hbtime>=5)
			{
				#ifdef SYS_DEBUG
				printf("����������\r\n");
				#endif
				AnyMSG_pack_send((unsigned char *)AnyMSG_MSG_TYPE_HEART_PKG,".",1);
				hbtime=0;
				if(hbrecvtimeflag>12)
				{
					#ifdef SYS_DEBUG
					printf("���½�������\r\n");
					#endif
					hbrecvtimeflag=0;
					AnyMSG_hs_flag=0;
					loginflag=0;
					c2c_suce_flag=0;
					hbflag=0;
					hbtime=0;
					LED2_OFF;
					LED3_OFF;
					close(SOCK_TCPC);
					delay_ms(200);
					goto cta;
				}
				hbrecvtimeflag++;
			 }
			
			 len=getSn_RX_RSR(SOCK_TCPC); /*����lenΪ�ѽ������ݵĳ���*/
			 
			if(len>0)
			{
				LED4_TOGGLE;
				if((!AnyMSG_hs_flag))//�Ƿ�������
				{
					recv(SOCK_TCPC,buff,len);
					buff[len]=0x00;
					if(strncmp((const char *)buff, (const char *)"HTTP", strlen((const char *)"HTTP")) == 0)
					{
							if((p = strstr((const char *)buff, (const char *)"Sec-WebSocket-Accept: ")) != NULL)    //��������ź�
							{
								p += strlen((const char *)"Sec-WebSocket-Accept: ");
								p=strtok((char *)p,"\r");
								if(AnyMSG_matchShakeKey(shakeKey, strlen((const char *)shakeKey), (unsigned char *)p, strlen((const char *)p)) == 0)  // ���ֳɹ�, ���͵�¼���ݰ�
								{
										AnyMSG_hs_flag=1;
										hslgreflag=0;
										len=0;
										goto wel;
								}
							}
						}
					}
					
					if(AnyMSG_hs_flag)
					{
						  memset(buff,0,4096);
							recv(SOCK_TCPC,msgheadbuff,2);
						  left=(msgheadbuff[0] & 0xf0)>>4;
						  right=(msgheadbuff[0] & 0x0f);
						  if(left==0x08)//����֡
							{
								if(right==0x02)//������֡
								{
									if((msgheadbuff[1] & 0x7F)==126)//�������ֽڳ���
									{
										recv(SOCK_TCPC,msgheadbuff2,2);
										AnyMSGdatalen=(msgheadbuff2[0] << 8) + msgheadbuff2[1];
										if(len-4>=AnyMSGdatalen)//���������ȴ���AnyMSGdatalen
										{
											recv(SOCK_TCPC,buff,AnyMSGdatalen);
											AnyMSG_depackge(((char *)buff));
											len=0;
										}else//����������С��AnyMSGdatalen
										{
	                    la:
											len=getSn_RX_RSR(SOCK_TCPC); 								  	         /*����lenΪ�ѽ������ݵĳ���*/
											if(len<AnyMSGdatalen)
											{
												delay_us(5);
												goto la;
											}
											recv(SOCK_TCPC,buff,AnyMSGdatalen);
											AnyMSG_depackge(((char *)buff));
											len=0;
										}
									}else if((msgheadbuff[1] & 0x7F)==127)//����8�ֽڳ���
									{
										
									}else if((msgheadbuff[1] & 0x7F)<126)//֡������126����//���ɳ��ȼ�Ӧ����Ϣ����
									{
										AnyMSGdatalen=msgheadbuff[1] & 0x7F;
										if(len-2>=AnyMSGdatalen)//���������ȴ���AnyMSGdatalen
										{
											recv(SOCK_TCPC,buff,AnyMSGdatalen);
											AnyMSG_depackge(((char *)buff));
											len=0;
										}else//����������С��AnyMSGdatalen
										{
											lb:
											len=getSn_RX_RSR(SOCK_TCPC); 								  	         /*����lenΪ�ѽ������ݵĳ���*/
											if(len<AnyMSGdatalen)
											{
												delay_us(5);
												goto lb;
											}
											recv(SOCK_TCPC,buff,AnyMSGdatalen);
											AnyMSG_depackge(((char *)buff));
											len=0;
										}
									}
								}else//�Ƕ�����֡
								{
									
								}
							}else//�ǽ���֡
							{
								  if(len-2<1024)
									{
										recv(SOCK_TCPC,buff,len-2);
									}else
									{
										i=(len-2)/1024;
										for(j=0;j<i;j++)
										{
											recv(SOCK_TCPC,buff,1024);
										}
										recv(SOCK_TCPC,buff,(len-2-(1024*i)));
									}
							}
						  len=0;
					}
				}
			  /*����͸����AnyMSG*/
				if(uartsendtime>45 || ((UART_RX_STA&0x3fff)>=648))
				{
					uartlen=UART_RX_STA&0x3fff;//�õ��˴ν��յ������ݳ���
					UART_RX_STA=0;
					if(uartlen>0)
					{	
						if(loginflag)
						{
							if(uart_flag)
							{
								uart_flag=0;
								AnyMSG_pack_send((unsigned char *)AnyMSG_MSG_TYPE_USER_MSG,(char *)UART_RX_BUFA,uartlen);
								memset(UART_RX_BUFA,0,UART_REC_LEN);
								uartsendtime=0;
							}else
							{
								uart_flag=1;
								AnyMSG_pack_send((unsigned char *)AnyMSG_MSG_TYPE_USER_MSG,(char *)UART_RX_BUFB,uartlen);
								memset(UART_RX_BUFB,0,UART_REC_LEN);
								uartsendtime=0;
							}
						}else
						{
							if(uart_flag)
							{
								uart_flag=0;
								memset(UART_RX_BUFA,0,UART_REC_LEN);
								uartsendtime=0;
							}else
							{
								uart_flag=1;
								memset(UART_RX_BUFB,0,UART_REC_LEN);
								uartsendtime=0;
							}
						}
					}else
					{
						uartsendtime=0;
					}
				}
		   				
				break;
			case SOCK_CLOSE_WAIT: 											    	         /*socket���ڵȴ��ر�״̬*/
			  AnyMSG_hs_flag=0;
			  loginflag=0;
			  c2c_suce_flag=0;
			  hbflag=0;
				hbtime=0;
			  LED2_OFF;
				LED3_OFF;
				close(SOCK_TCPC);
#ifdef SYS_DEBUG
				printf("���ӶϿ�\r\n");
#endif
				break;
		}
	}
}
int AnyMSG_pack_send(unsigned char *type,char *buff, unsigned long int buffsize)
{
	unsigned char AnyMSG_pack[2048];
	u8 ret;
	u16 packlens = 0;
	memset(AnyMSG_pack,0,2048);
	if(strstr((const char *)type, AnyMSG_MSG_TYPE_USER_MSG))
	{
		packlens = sprintf((char *)AnyMSG_pack,
				 "{\"opr\":{\"code\": \"%s\",\"desp\": \"%s\"},\"msg\":{\"srcID\": \"%d\",\"desID\": \"%d\",\"content\": \"%.*s\",\"time\": \"%d\"}}",
				 type, "AAAAAAAA", scid, dcid, (int)buffsize, buff,20190726);
		AnyMSG_pack[packlens]='\0';
#ifdef SYS_DEBUG
		 printf("����������:%s\r\n",AnyMSG_pack);
#endif
	}
	else if(strstr((const char *)type,AnyMSG_MSG_TYPE_HEART_PKG))
	{
		packlens = sprintf((char *)AnyMSG_pack,
				 "{\"opr\":{\"code\": \"%s\",\"desp\": \"%s\"},\"msg\":{\"srcID\": \"%d\",\"desID\": \"%d\",\"content\": \"%.*s\",\"time\": \"%d\"}}",
				 type, "AAAAAAAA",scid,0, (int)buffsize, buff,20190726);
		AnyMSG_pack[packlens]='\0';
	}
		else
		{
		packlens = sprintf((char *)AnyMSG_pack,
				 "{\"opr\":{\"code\": \"%s\",\"desp\": \"%s\"},\"msg\":{\"srcID\": \"%d\",\"desID\": \"%d\",\"content\": \"%.*s\",\"time\": \"%d\"}}",
				 type, "AAAAAAAA",scid,dcid, (int)buffsize, buff,20190726);
		AnyMSG_pack[packlens]='\0';
	  }
#ifdef SYS_DEBUG
		printf("datalen:%d\r\n",strlen((char *)AnyMSG_pack));
		printf("packlens:%d\r\n",packlens);
#endif
	  ret=AnyMSG_send(AnyMSG_pack,packlens,WCT_TXTDATA);		
		return ret;
	
}
int AnyMSG_send(unsigned char *data, unsigned int dataLen, AnyMSG_CommunicationType type)
{
    unsigned char *AnyMSGPackage;
    unsigned int retLen, ret;
    //---------- AnyMSG���ݴ�� ----------
    AnyMSGPackage = (unsigned char *)calloc(1, sizeof(char)*(dataLen + 128));
	  memset(AnyMSGPackage, 0, (dataLen + 128));
    retLen = AnyMSG_enPackage(data, dataLen, AnyMSGPackage, (dataLen + 128),1, type);
		
		ret=send(SOCK_TCPC,AnyMSGPackage,retLen);
		if(ret<retLen)
		{
#ifdef SYS_DEBUG
			 printf("send data error\r\n");
#endif
		}
    free(AnyMSGPackage);
    return ret;
}

int AnyMSG_print(u8 *hex,int len)
{
   int i=0;
	 for(i=0;i<len;i++)
	{
		printf("%c",hex[i]);
	}
	return 0;
}
/*******************************************************************************
 * ����: AnyMSG_depackge
 * ����: db ���
 * �β�: fd�����Ӿ��
 *          *data : ���ݽ��յ�ַ
 *          dataMaxLen : ������������󳤶�
 * ����: <= 0 û���յ���Ч����        > 0 �ɹ����ղ��������
 * ˵��: ��
 ******************************************************************************/
int AnyMSG_depackge(char *data)
{
	  u8 any_hex_msg[4096]={0};
		memset(any_hex_msg,0,4096);
	  memset(mpphead,0,MSG_HEAD_LENGTH);
		memcpy(mpphead,data,MSG_HEAD_LENGTH);
	  if(((msg_t *)mpphead)->type==MSG_TYPE_WELCOME)
		{
			loginflag=1;
			hbflag=1;
			hslgreflag=0;
			scid=((msg_t *)mpphead)->destination_cid;
			if((scid>0)&&(scid<65535))
			{
				c2c_suce_flag=1;
				LED2_ON;
			}
#ifdef SYS_DEBUG
			printf("destination_cid:%d\r\n",((msg_t *)mpphead)->destination_cid);
#endif
			memset(mpphead,0,MSG_HEAD_LENGTH);
		}else if((((msg_t *)mpphead)->type==MSG_TYPE_USER_MSG_REP)&&dcid)
		{
			hbsendflag=0;
			memset(mpphead,0,MSG_HEAD_LENGTH);
		}else if((((msg_t *)mpphead)->type==MSG_TYPE_USER_MSG)&&dcid)
		{
			memcpy(any_hex_msg,data+40,((msg_t *)mpphead)->content_length);
			AnyMSG_print(any_hex_msg,((msg_t *)mpphead)->content_length);
			memset(mpphead,0,MSG_HEAD_LENGTH);
		}else if(((msg_t *)mpphead)->type==MSG_TYPE_HEART_PKG_REP)
		{
			hbrecvtimeflag=0;
			memset(mpphead,0,MSG_HEAD_LENGTH);
#ifdef SYS_DEBUG
			printf("��������Ӧ\r\n");
#endif
		}else if(((msg_t *)mpphead)->type==130)
		{
			dcid=((msg_t *)mpphead)->source_cid;
			memset(mpphead,0,MSG_HEAD_LENGTH);
#ifdef SYS_DEBUG
			printf("��ҳ��CID�ѻ�ȡ\r\n");
			printf("dcid:%d\r\n",dcid);
#endif
			if(dcid>0)
			{
				LED3_ON;
				__HAL_UART_ENABLE_IT(&husart_debug,UART_IT_RXNE);		//���������ж�
			}else
			{
				dcid=0;
				LED3_OFF;
			}
		}
		return 0;
}
